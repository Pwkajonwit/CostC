import { NextRequest, NextResponse } from "next/server";
import { clearCache } from "@/lib/utils/cache";
import { TABLES } from "@/lib/config";
import { getRows } from "@/lib/db";
import { isCommittedBill } from "@/lib/bills/bill-status";
import { getRowYear } from "@/lib/utils/dates";
import { isRowMatchingYearOrPeriod } from "@/lib/fiscal-periods/fiscal-period-types";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export async function GET(request: NextRequest) {
  const isRefresh = request.nextUrl.searchParams.get("refresh") === "1";
  if (isRefresh) {
    clearCache("rows:");
    clearCache("dashboard");
  }

  const [dataRows, projectRows, pettyCashRows] = await Promise.all([
    getRows(TABLES.DATA),
    getRows(TABLES.PROJECT),
    getRows(TABLES.PETTY_CASH).catch(() => []),
  ]);

  const validDataRows = dataRows.filter(isCommittedBill);
  const yearParam = request.nextUrl.searchParams.get("year")?.trim() || request.cookies.get("costlab_selected_year")?.value?.trim();
  const yearFilteredRows = (!yearParam || yearParam === "all")
    ? validDataRows
    : validDataRows.filter((r) => isRowMatchingYearOrPeriod(r, yearParam));

  const yearFilteredPettyCash = (!yearParam || yearParam === "all")
    ? pettyCashRows
    : pettyCashRows.filter((r) => isRowMatchingYearOrPeriod(r, yearParam));

  const response = NextResponse.json({
    dataRows: yearFilteredRows,
    projectRows,
    pettyCashRows: yearFilteredPettyCash,
    totalRows: yearFilteredRows.length,
    projectRowsCount: projectRows.length
  });

  response.headers.set(
    "Cache-Control",
    "no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0"
  );
  response.headers.set("Pragma", "no-cache");

  return response;
}
